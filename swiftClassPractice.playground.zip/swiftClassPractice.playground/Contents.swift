import UIKit

class Animal {
    var legs: Int
    
    init(legs: Int) {
        self.legs = legs
    }
    
    func speak(){
        print("Makes noise")
    }
}

class Dog: Animal {
    override func speak(){
        print("Woof Woof")
    }
}

class Cat: Animal {
    var isTame: Bool
    
    init(isTame: Bool){
        self.isTame = isTame
        super.init(legs: 4)
    }
    
    override func speak(){
        print("Meow")
    }
}

class Corgi: Dog {
    override func speak(){
        print("Wooooof")
    }
}

class Poodle: Dog {
    override func speak(){
        print("Wof")
    }
}

class Persian: Cat {
    override func speak(){
        print("Meowww")
    }
}

class Lion: Cat {
    init(){
        super.init(isTame: false)
    }
    
    override func speak(){
        print("Roar")
    }
}

let sloth = Cat(isTame: false)
sloth.speak()

